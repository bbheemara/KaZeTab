function getStorage(keys) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(keys, (res) => resolve(res || {}));
    } catch (e) {
      resolve({});
    }
  });
}

function setWallpaperUrl(url) {
  if (!url) return;
  const container = document.getElementById('wallpaper') || document.body;
  container.style.backgroundImage = `url("${url}")`;
  container.style.backgroundSize = 'cover';
  container.style.backgroundPosition = 'center';
  container.style.backgroundRepeat = 'no-repeat';
}

function getSlotForHour(h) {
  if (h < 12) return 'morning';
  if (h < 18) return 'afternoon';
  if (h < 21) return 'evening';
  return 'night';
}

async function loadWallpaperOnStart() {
  const res = await getStorage(['wallpaperUrl', 'timeBasedGreetings', 'timeSlotCategories', 'mode']);
  const h = new Date().getHours();
  // the below lines are for testing purpose of wallpaper set from settings-form
// const urlParams = new URLSearchParams(window.location.search); 
// const debugHour = urlParams.has('hour') ? Number(urlParams.get('hour')) : null;
// const h = (debugHour !== null && !isNaN(debugHour)) ? debugHour : new Date().getHours();
  const slot = getSlotForHour(h);

  if (res.mode === 'different' && res.timeSlotCategories) {
    const key = `wallpaper_${slot}`;
    const slotRes = await getStorage([key]);
    if (slotRes && slotRes[key]) {
      setWallpaperUrl(slotRes[key]);
      return;
    }

    
    if (res.wallpaperUrl) {
      setWallpaperUrl(res.wallpaperUrl);
      return;
    }

   
    return;
  }


  if (res.wallpaperUrl) {
    setWallpaperUrl(res.wallpaperUrl);
    return;
  }

}


function showGreetingIfNeeded() {
  chrome.storage.local.get(['timeBasedGreetings'], (result) => {
    const timebased = !!result.timeBasedGreetings;
    if (!timebased) return;

    const time = new Date();
    const h = time.getHours();
    const greetings = h < 12
      ? 'Morning Champ!'
      : h < 18
        ? 'Afternoon!'
        : h <= 22
          ? 'Evening'
          : 'Night, Go Sleep!';

    const greetingDisplay = document.getElementById('greeting-text');
    if (greetingDisplay) greetingDisplay.textContent = greetings;
  });
}


chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== 'object') return;
  if (msg.type === 'wallpaper-updated' && msg.url) {
  
    setWallpaperUrl(msg.url);
  }

  if (msg.type === 'mode-changed') {
    loadWallpaperOnStart(); 
  }
});


document.addEventListener('DOMContentLoaded', async () => {
  try {
    await loadWallpaperOnStart();
  } catch (err) {
    console.error('Error while loading wallpaper on start:', err);
  }

  try {
    showGreetingIfNeeded();
  } catch (e) {
    console.error('Greeting error', e);
  }

  
  const searchForm = document.getElementById('searchForm');
  const searchBox = document.getElementById('searchBox');

  if (searchForm && searchBox) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const query = searchBox.value.trim();
      if (!query) return;
      try {
        if (window.chrome && chrome.search && typeof chrome.search.query === 'function') {
          chrome.search.query({ text: query });
        } else {
          window.open('https://www.google.com/search?q=' + encodeURIComponent(query), '_blank');
        }
      } catch (err) {
        window.open('https://www.google.com/search?q=' + encodeURIComponent(query), '_blank');
      }
    });
  }
});
